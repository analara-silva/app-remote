-- --------------------------------------------------------
-- Servidor:                     127.0.0.1
-- Versão do servidor:           10.4.32-MariaDB - mariadb.org binary distribution
-- OS do Servidor:               Win64
-- HeidiSQL Versão:              12.8.0.6908
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

-- Copiando dados para a tabela servidor.cidade: ~2 rows (aproximadamente)
INSERT INTO `cidade` (`id_cidade`, `nome`, `estado_uf`) VALUES
	(1, 'Presidente Prudente', 'SP'),
	(2, 'Álvares Machado', 'SP');

-- Copiando dados para a tabela servidor.estado: ~14 rows (aproximadamente)
INSERT INTO `estado` (`id_estado`, `nome`, `uf`) VALUES
	(1, 'São Paulo', 'SP'),
	(2, 'Rio de Janeiro', 'RJ'),
	(3, 'Mato Grosso', 'MT'),
	(4, 'Acre', 'AC'),
	(5, 'Alagoas', 'AL'),
	(6, 'Rio Grande do Norte', 'RN'),
	(7, 'Amapá', 'AP'),
	(8, 'Amazonas', 'AM'),
	(9, 'Mato Grosso do Sul', 'MS'),
	(10, 'Paraná', 'PR'),
	(11, 'Tocantins', 'TO'),
	(12, 'Sergipe', 'SE'),
	(13, 'Pernambuco', 'PE'),
	(14, 'Minas Gerais', 'MG');

-- Copiando dados para a tabela servidor.grupo: ~3 rows (aproximadamente)
INSERT INTO `grupo` (`id_grupo`, `nome`) VALUES
	(3, 'Familia Buscapé'),
	(1, 'Los Reales'),
	(2, 'Terceirão');

-- Copiando dados para a tabela servidor.usuario: ~6 rows (aproximadamente)
INSERT INTO `usuario` (`id_usuario`, `nome`, `email`, `senha`, `nome_grupo`, `situacao`) VALUES
	(1, 'Gabriel', 'gabe2@gmail.com', '15122007', 'Los Reales', 'Editor'),
	(3, 'Ana Lara', 'ana@gmail.com', 'ana123', 'Familia Buscapé', 'Editor'),
	(4, 'Lucas Barros', 'lucah.barros@gmail.com', '123', 'Los Reales', 'Leitor'),
	(5, 'Yasmin', 'yas222@gmail.com', 'dfsfd', 'Terceirão', 'Admin'),
	(6, 'Betina', 'betina51@gmail.com', 'dfds4rfdw', 'Terceirão', 'Editor'),
	(7, 'João Vitor', 'jovi44@gmail.com', 'sewfds', 'Los Reales', 'Leitor');

/*!40103 SET TIME_ZONE=IFNULL(@OLD_TIME_ZONE, 'system') */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
