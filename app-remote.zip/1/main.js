const express = require('express') // Importa o modulo 'express' para o projeto
const mysql = require('mysql2/promise')
const cors = require('cors')
const { json } = require('express/lib/response')
const path = require('path') // Independente do sistema operacional ele achará o cominho para os arquivos.
const res = require('express/lib/response')

const App = express() // Configra o express para ser usado

App.set("view engine", "ejs")
App.set("views", path.join(__dirname, "mvc/views") )
App.use(express.static(path.join(__dirname, "public")))
App.use(express.urlencoded({extended: true}))
App.use(express.json())
App.use(cors())


const connection = mysql.createPool({
    host: '127.0.0.1',
    user: 'root',
    password: '',
    database: 'servidor'
});

App.get('/dados_login', async (req, res) =>{
    const sql = 'select * from usuario'
    const [rows] = await connection.execute(sql)

    res.json({
        dados: rows
    })
})

App.get('/statusbd', async (req, res) => {
    try {
        const [rows] = await connection.execute('SELECT NOW()');
        res.json({ msg: rows });
    } catch (err) {
        resposta.status(500).json({ error: 'Erro ao conectar ao banco de dados!' });
    }
});


// Endpoint
App.get("/", (requisicao, resposta) => {
    resposta.render("index.ejs")
})

App.post("/home", async (req, res) => {
    
    const nome = req.body.nome
    const senha = req.body.senha

    const [rows] = await connection.execute(
        "SELECT * FROM usuario WHERE nome = ?", [nome]);
        
        if (rows.length === 0) {
            res.render('index.ejs')
            console.log('Usuario não encontrado')
        } else {
            
            const senhaBanco = rows[0].senha;

            
            if (senha === senhaBanco) {
                
                res.render("inicio.ejs");
            } else {

                res.render("index")
                console.log('Senha não encontrada')
            }
        }
    }
);

App.get("/usuarios", async (req, res) => {
    try {
        const [rows] = await connection.execute("SELECT id_usuario, nome, email, nome_grupo FROM usuario");
        res.render("user.ejs", { usuarios: rows }); // Passa os dados para o EJS
    } catch (error) {
        console.error("Erro ao buscar usuários:", error);
        res.status(500).send("Erro ao buscar usuários");
    }
});

App.post("/excluir/:id", async (req, res) => {

    const { id_usuario } = req.params;

    try {
        await connection.execute("DELETE * FROM usuario WHERE id_usuario = ?", [id]);
        res.redirect("/usuarios"); // Recarrega a tabela após excluir
    } catch (error) {
        console.error("Erro ao excluir usuário:", error);
        res.status(500).send("Erro ao excluir usuário");
    }
});

App.get("/editar/:id", async (req, res) => {
    const { id_usuario } = req.params;
    console.log("ID recebido para edição:", id_usuario); // Verifique se o ID está correto

    try {
        const [rows] = await connection.execute("SELECT * FROM usuario WHERE id_usuario = ?", [id]);

        if (rows.length > 0) {
            res.render("editar.ejs", { usuario: rows[0] });
        } else {
            res.redirect("/usuarios");
        }
    } catch (error) {
        console.error("Erro ao buscar usuário:", error);
        res.status(500).send("Erro ao buscar usuário");
    }
});



// Deixa disponível o serviço
App.listen(3000, () => {
    console.log("Aplicação no ar")
})
